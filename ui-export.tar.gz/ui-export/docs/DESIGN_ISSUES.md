# مشاكل التصميم الحالية — Arabic ERP System

## 🔴 مشاكل حرجة (Critical)

1. **Light Mode غير مكتمل**
   - بعض عناصر الـ UI تستخدم ألوان hardcoded للـ dark mode (`text-white`, `bg-black/20`)
   - في الـ light mode تظهر نصوص بيضاء على خلفية بيضاء في بعض المكونات
   - المعالجة حالياً بـ CSS overrides كثيرة في `index.css` (غير maintainable)

2. **Select elements مكسورة في Light Mode**
   - `<select>` و `<select option>` عندهم `background-color: #14192e` hardcoded
   - يظهر بشكل سيء جداً في الوضع الفاتح

3. **Mobile Responsive غير متوازن**
   - صفحة الـ POS غير قابلة للاستخدام على الموبايل
   - الجداول الكبيرة (Sales, Purchases) تتجاوز حدود الشاشة على الموبايل

## 🟡 مشاكل متوسطة (Medium)

4. **تعارض الـ transition العام**
   - `*, *::before, *::after { transition: ... }` على كل العناصر
   - يبطئ الأداء ويسبب animations غير مقصودة في بعض المكونات

5. **font-size غير متسق**
   - Dark mode: `font-size` غير محدد على body (يرث من المتصفح)
   - Light mode: `font-size: 14px` محدد على body
   - هذا يسبب فرق مرئي عند التبديل بين الثيمات

6. **KPI Cards (stat-card) في Light Mode فقيرة**
   - في الـ dark mode: ألوان gradients جميلة وglow effects
   - في الـ light mode: كلها تبدو نفس الشيء (بيضاء بحدود ملونة بسيطة)
   - تفقد الـ visual hierarchy والتمييز بينها

7. **Sidebar collapse مش موجود**
   - السايدبار دايماً مفتوح على الديسكتوب
   - يأخذ مساحة كبيرة من المحتوى خصوصاً على شاشات 1366px

8. **Header مكرر في بعض الصفحات**
   - بعض الصفحات فيها عنوان داخل الـ header العام + عنوان ثاني داخل المحتوى

## 🔵 مشاكل بسيطة (Minor)

9. **Empty States تصميمها متشابه جداً**
   - كل الصفحات لما تكون فارغة تظهر نفس الـ empty state component بدون customization

10. **Skeleton Loading غير متوازن**
    - بعض الصفحات فيها skeleton لكن أخرى تظهر فراغ مباشرة

11. **Scrollbar بسيطة جداً**
    - عرض 4px قد يكون صغير جداً للمستخدمين على touch screens

12. **RTL Direction في بعض المكونات الخارجية**
    - بعض مكونات Radix UI مش بتعمل بشكل صحيح مع RTL (مثلاً: Dropdown alignment)

13. **Focus States غير واضحة**
    - في الـ dark mode الـ focus ring أصفر (`.ring = --ring: 38 95% 55%`)
    - في الـ light mode الـ focus غير واضح على كثير من المدخلات

14. **Color-only Status Indicators**
    - الحالات (ناجح/فاشل/معلق) تعتمد على اللون فقط دون أيقونة أو نص مساعد
    - مشكلة accessibility للمستخدمين عمى الألوان

## 💡 توصيات للتحسين

- استبدال الـ `text-white` hardcoded بـ CSS variables ديناميكية
- إضافة sidebar collapse button للـ desktop
- تحسين الـ mobile layout للـ POS page
- توحيد الـ font-size system بين الثيمات
- إضافة icons للـ status indicators
- مراجعة الـ RTL alignment في مكونات Radix UI
