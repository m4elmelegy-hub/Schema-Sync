# Tech Stack — Arabic ERP System (Halal Tech)

## Frontend Framework
- **React 19** (with concurrent features)
- **wouter** — lightweight client-side routing

## Styling
- **Tailwind CSS v4** (new `@import "tailwindcss"` syntax, no config file)
- **Custom CSS** in `index.css` — glassmorphism classes, RTL utilities
- **tw-animate-css** — animation utilities

## UI Component Library
- **Radix UI** (primitives: Dialog, Select, Popover, etc.)
- **Custom component wrappers** in `src/components/ui/`
- **lucide-react** — icons
- **sonner** — toast notifications

## Data Fetching & State
- **TanStack Query (React Query) v5** — server state
- **React Context** — auth, settings, warehouse selection

## Forms
- **react-hook-form** + **Zod** validation

## Animations
- **Framer Motion** — page transitions, micro-interactions
- **anime.js / GSAP** — custom animation sequences

## Charts
- **Recharts** — financial charts and KPI visualizations

## Typography
- **Tajawal** font (Arabic) — from Google Fonts

## Themes Supported
- Dark (default) — deep navy glassmorphism
- Light (Soft) — clean white cards
- Light (High Contrast) — accessibility mode

## Language & Direction
- Arabic UI, RTL layout (`direction: rtl` on body)
- All labels and navigation in Arabic

## Key Design Patterns
- Glassmorphism cards with `backdrop-filter: blur()`
- Gradient border cards (`.card-premium`, `.stat-card`)
- Animated sidebar with active indicator bar on right edge
- Mobile bottom navigation bar for small screens
