# Halal Tech ERP — Frontend UI Export
**Date:** April 2026 | **Version:** 2.0

## Structure
```
ui-export/
├── screenshots/
│   ├── desktop/           # لقطات سطح المكتب (1440x900)
│   └── mobile/            # لقطات الموبايل (390x844)
├── source-files/
│   ├── layout/            # layout.tsx, header, sidebar, page-transition
│   ├── ui-components/     # buttons, inputs, tables, dialogs, forms
│   ├── pages/             # أهم 10 صفحات
│   ├── styles/            # index.css (global styles), vite.config.ts
│   └── App.tsx            # تعريف الـ routes
└── docs/
    ├── STACK.md           # التقنيات المستخدمة
    └── DESIGN_ISSUES.md   # مشاكل التصميم الحالية
```

## Note on Screenshots
لقطات الشاشة للصفحات الداخلية (dashboard, sales, pos...) تتطلب تسجيل دخول.
بيانات الدخول: **admin / 123456**

## Pages List (22 page)
Login, Dashboard, POS, Sales, Purchases, Products, Inventory,
Customers, Expenses, Income, Tasks, Profits, Reports, Accounts,
Journal Entries, Receipt Vouchers, Deposit Vouchers, Payment Vouchers,
Safe Transfers, Financial Transactions, Settings, Access Denied

## Design Goal
تحسين UI/UX فقط بدون تغيير الـ backend
